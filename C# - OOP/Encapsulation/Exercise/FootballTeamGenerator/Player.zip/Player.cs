﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballTeamGenerator
{
    public class Player
    {
        private const int statsMinValue = 0;
        private const int statsMaxValue = 100;
        private const string statsExceptionMessage = "{0} should be between 0 and 100.";

        private string name;
        //Stats probably could be done with dictionary...
        private double endurance;
        private double sprint;
        private double dribble;
        private double passing;
        private double shooting;
        private double skillLevel;

        public Player(string name, double endurance, double sprint, double dribble, double passing, double shooting)
        {
            this.Name = name;
            this.Endurance = endurance;
            this.Sprint = sprint;
            this.Dribble = dribble;
            this.Passing = passing;
            this.Shooting = shooting;
            this.SkillLevel = CalculateSkillLevel();
        }

        public string Name
        {
            get
            {
                return name;
            }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception("A name should not be empty.");
                }
                name = value;
            }
        }
        public double Endurance
        {
            get
            {
                return this.endurance;
            }
            private set
            {
                if (value < statsMinValue || value > statsMaxValue)
                {
                    throw new Exception(string.Format(statsExceptionMessage, nameof(this.Endurance)));
                }
                endurance = value;
            }
        }
        public double Sprint
        {
            get
            {
                return this.sprint;
            }
            private set
            {
                if (value < statsMinValue || value > statsMaxValue)
                {
                    throw new Exception(string.Format(statsExceptionMessage, nameof(this.Sprint)));
                }
                sprint = value;
            }
        }
        public double Dribble
        {
            get
            {
                return this.dribble;
            }
            private set
            {
                if (value < statsMinValue || value > statsMaxValue)
                {
                    throw new Exception(string.Format(statsExceptionMessage, nameof(this.Dribble)));
                }
                dribble = value;
            }
        }
        public double Passing
        {
            get
            {
                return this.passing;
            }
            private set
            {
                if (value < statsMinValue || value > statsMaxValue)
                {
                    throw new Exception(string.Format(statsExceptionMessage, nameof(this.Passing)));
                }
                passing = value;
            }
        }
        public double Shooting
        {
            get
            {
                return this.shooting;
            }
            private set
            {
                if (value < statsMinValue || value > statsMaxValue)
                {
                    throw new Exception(string.Format(statsExceptionMessage, nameof(this.Shooting)));
                }
                shooting = value;
            }
        }
        public double SkillLevel
        {
            get
            {
                return this.skillLevel;
            }
            private set
            {
                skillLevel = value;
            }
        }

        private double CalculateSkillLevel()
        {
            double result = (this.Endurance + this.Sprint + this.Dribble + this.Passing + this.Shooting) / 5;
            return result;
        }
    }
}
